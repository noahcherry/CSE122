#include "blackbox.h"
#include <time.h>

/* random_number: generates a pseudo-random
long unsigned between 0 and 2^(-64) - 1
seed random() with srandom(time(NULL)) before you call this*/
unsigned long random_number(void) 
{
        unsigned long n, p, r;
        int i;

        n = 0;
        for(i = 0, p = 1; i < 8; i++, p*= 256) {

                /* we have p = 256-i*/
                /* randomvalue between 0 and 255*/
                r = random() % 256;

                /* add this pseudo-random byte to n*/
                n += r * p;

        } /* repeat 8 times, so we have 64 pseudo-random bits*/

        return n;
}

void reverse_list(unsigned long list_size, unsigned long* a) 
{
        unsigned long tmp;
        unsigned long* c;
        unsigned long* b;

        c = a;
        b = a + list_size - 1;
        /* setp back from the end of the list*/
        while(c < b) {
        
                tmp = *b;
                *b = *c;
                *c = tmp;

                c++;
                b--;
        }
        //printf("the code seg faults without this line. no joke.\n");
}

void shuffle_list(unsigned long list_size, unsigned long *a) 
{
        /* *list is a sorted list of size list_size*/
        srandom(time(NULL));
        unsigned long i = list_size - 1;
        unsigned long j;
        unsigned long tmp;
        unsigned long* c;
        unsigned long* b;

        c = a;
        b = a + list_size - 1;

        while(i > 0) {
                /* pick a random element between 0 and i to swap*/
                j = random_number() % (list_size - 1);

                c = a;
                b = a + j;

                tmp = *b;
                *b = *c;
                *c = tmp;

                i--;
                c++;
        }
}

/*doesn't do the ones that need lists*/
void function_test_no(unsigned long list_size, FILE* f, unsigned long n, void (foo)(unsigned long n))
{        
        double time;
        clock_t start, end;

        start = clock();

        foo(n);

        end = clock();
        time = (double)(end - start) / CLOCKS_PER_SEC;

        printf("Time elapsed:\t%f seconds\n\n", (double) time);
        fprintf(f, "%lu %f\n", n, time);

}

void function_test(unsigned long list_size, FILE* f, unsigned long n, unsigned long* a, void (foo)(unsigned long* a, unsigned long n))
{        
        double time;
        clock_t start, end;

        start = clock();

        foo(a, n);

        end = clock();
        time = (double)(end - start) / CLOCKS_PER_SEC;

        printf("Time elapsed:\t%f seconds\n\n", (double) time);
        fprintf(f, "%lu %f\n", n, time);

}

void fill_list(unsigned long list_size, unsigned long* list) 
{
        int i;
        for(i = 0; i < list_size; i++) {
                *(list + i) = i;
        }
}

int main(void) {
        unsigned long list_size = 20;

        int togrev = 0;
        int togshu = 0;        

        int choice;
        unsigned long n = 5;
        char buff[1024]; 

        FILE *f;

        unsigned long* list = malloc(list_size * sizeof(unsigned long));
        fill_list(list_size, list);

        while(1) {
                /*!!!--it is users responsibility to build a list before using--!!!*/
                /*!!!--funcions 3 or 6--!!!*/
                printf("\t!-3 and 6 require a new list on every call-!\n");
                printf("The next list will be ");
                if(togrev == 1 && togshu == 0)
                        printf("\t\t\tREVERSE-SORTED");
                else if(togshu == 0)
                        printf("\t\t\tSORTED");
                else if(togshu == 1)
                        printf("\t\t\tSHUFFLED");
                printf("\n");
                printf("1-7) desired function\n");
                printf("8) toggle reverse list generation\t");
                if(togrev == 1)
                        printf("ON\n");
                else
                        printf("OFF\n");
                printf("9) toggle shuffle list generation\t");
                if(togshu == 1)
                        printf("ON\n");
                else
                        printf("OFF\n");
                printf("10) input value for n\tcurrently: \t%lu \n12) exit\n", n);
                fgets(buff, 1024, stdin);
                sscanf(buff, "%d", &choice);

                if(choice == 12){
                        free(list);
                        exit(EXIT_SUCCESS);
                }else if(choice == 10) {
                        printf("enter value n: ");
                        fgets(buff, 1024, stdin);
                        sscanf(buff, "%lu", &n);
                }else if(choice == 8) {
                        if(togrev == 1)
                                togrev--;
                        else
                                togrev++;
                }else if(choice == 9) {
                        if(togshu == 1)
                                togshu--;
                        else
                                togshu++;
                }else if (choice < 8 && choice > 0) {
                        if(choice == 3 || choice == 6) {

                                printf("enter list size: ");
                                fgets(buff, 1024, stdin);
                                sscanf(buff, "%lu", &list_size);
                                n = list_size;
                                list = realloc(list, list_size * sizeof(unsigned long));
                                fill_list(list_size, list);
                                if(togrev == 1)
                                        reverse_list(list_size, list);
                                if(togshu == 1)
                                        shuffle_list(list_size, list);

                                void (*fooyes)(unsigned long* list, unsigned long n);
                                if(choice == 3) {
                                        fooyes = &function_3;
                                        f = fopen("f3.txt", "a");
                                }
                                else{
                                        fooyes = &function_6;
                                        f = fopen("f6.txt", "a");
                                }
                                function_test(list_size, f, n, list, fooyes);
                        }
                        else {
                                void (*foono)(unsigned long n);
                                if(choice == 1) {
                                        foono = &function_1;
                                        f = fopen("f1.txt", "a");
                                }
                                if(choice == 2) {
                                        foono = &function_2;
                                        f = fopen("f2.txt", "a");
                                }
                                if(choice == 4) {
                                        foono = &function_4;
                                        f = fopen("f4.txt", "a");
                                }
                                if(choice == 5) {
                                        foono = &function_5;
                                        f = fopen("f5.txt", "a");
                                }
                                if(choice == 7) {
                                        foono = &function_7;
                                        f = fopen("f7.txt", "a");
                                }
                                function_test_no(list_size, f, n, foono);
                        }
                fclose(f);
                }
        } 
        return 0;
}