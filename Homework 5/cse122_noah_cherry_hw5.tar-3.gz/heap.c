#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>

#define LEN 4096


struct heap_t {
	int last; 		/* index of last heap element in data array */
	int size;               /* number of elements in array */
	int max; 		/* allocated size of array */
	int *data;		/* the data array */

};

enum {INIT = 1, GROW = 2};

/*sinks from i to n (indexes)*/
void sink(struct heap_t *heap, int i, int n)
{

        while ( i * 2 + 1 < n) {
                int kiddo = 2 * i + 1;
                /*find the smallest child of i*/
                if (kiddo + 1 < n) {
                        if (heap->data[kiddo] < heap->data[kiddo + 1])    /*compare l and r child to find smallest*/
                                kiddo = kiddo + 1;
                }
                /*swap parent w/ child if its larger*/
                if(heap->data[i] < heap->data[kiddo]) {
                        /*swap index i with it's child if the child is larger*/
                        int temp = heap->data[i];
                        heap->data[i] = heap->data[kiddo];
                        heap->data[kiddo] = temp;
                        /*new node to examine in next loop iteration*/
                        i = kiddo;
                }
                else
                        return;
        }
}


int main(int argc, char **argv) 
{

	char buf[LEN];
	FILE *fp = NULL;
	int i = 0;

        int j = 0;

       	if (argc != 2) {
		printf("error in input\n");
		printf("usage: ./heap [FILE]\n");
		printf("[FILE] is a list of integers one per line\n");
		exit(EXIT_FAILURE);
	}
	else {
		fp = fopen(argv[1], "r");
		assert(fp);
	}

	struct heap_t *heap = malloc(sizeof(struct heap_t));
	heap->last = 0;
	heap->size = INIT;
	heap->max = INIT;
	heap->data = NULL;

	while (fgets(buf, LEN, fp)) {

		/* read in data from file */
		/* assign to heap->data */

		/* grow the array as necessary */
		if (heap->size > heap->max) {
			heap->data = realloc(heap->data, GROW * heap->max *sizeof(int));
			assert(heap->data);
			heap->max = GROW * heap->max;
		}
		else if (heap->data == NULL) {
			heap->data = malloc(INIT * sizeof(int));
			assert(heap->data);
		}
		*(heap->data + i) = atoi(buf); 
		heap->size++;
		i++;
	}	
		       

	/* size is off by one */
	heap->size--;

        /*order the values into a heap*/
        for (j = (heap->size) / 2; j >= 0; j--) {
                sink(heap, j, heap->size);
        }
                /*uncomment to see heap before the sort begins*/
                /*
	        for (i = 0; i < heap->size; i++) {
		        printf("%d\t", *(heap->data + i));	
	        }
		        printf("\n-\t-\t-\t\n");
                */

        /*the actual sort*/
        for(j = (heap->size)- 1; j >= 0; j--) {

                /*move root to the tail and make the last index the new root*/
                int tmp = heap->data[j];
                heap->data[j] = heap->data[0];
                heap->data[0] = tmp;

                /*uncomment to see each swap step diaplayed*/
                /*
	        for (i = 0; i < heap->size; i++) {
		        printf("%d\t", *(heap->data + i));	
	        }
		        printf("\n-\t-\t-\t\n");
                */

                /*remake the heap*
                 *sort from index 0(root) to j(the previous end)*/
                sink(heap, 0, j);
        }


	/* send data to stdin -- if you correctly built a heapsort
         * this will print the data in ascending order */
	for (i = 0; i < heap->size; i++) {
		printf("%d\n", *(heap->data + i));	
	}


	/* cleanup */
	free(heap->data);
	free(heap);
	fclose(fp);

	return 0;
}
