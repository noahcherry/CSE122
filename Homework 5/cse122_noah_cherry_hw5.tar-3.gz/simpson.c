#include <stdio.h>
#include <math.h>


double integrate(double (*f)(double x), double a, double b)
{

	double integral = 0.0;	/* area of rectangle */


	integral = ((b - a) / 6) * (f(a) + (4 * f((a + b) / 2)) + f(b));

	return integral;		/* area under the curve */

}


int main(void)
{
	double integral;
	/* integerate with sin, cos, log, sqrt, */
	//integral = integrate(cos, 0.0, M_PI/2);
	printf("integral of ln(x) from 0.5 to 2 is %lf\n", integrate(log, 0.5, 2));
	printf("integral of e^x from 0 to 1 is %lf\n", integrate(exp, 0.0, 1));
	printf("integral of cos(x) from 0 to pi/2 is %lf\n", integrate(cos, 0.0, M_PI_2));
	printf("integral of sin(x) from 0 to pi/2 is %lf\n", integrate(sin, 0.0, M_PI_2));
	printf("integral of sqrt(x) from 0 to 10 is %lf\n", integrate(sqrt, 0.0, 10));
	return 0;
}
