#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LEN 4096

struct data_t {
	int nval; 		/* current number of values in array */
	int max; 		/* allocated number of values */
	char** data;		/* the data array */
};

enum {INIT = 1, GROW = 2};

int search(char **data, int nval, char *word)
{
        int low = 0;
        int middle;
        int high = nval - 1;

        while (low <= high) {
                middle = (low + high) / 2;

                if (strcmp(data[middle], word) > 0)
                        high = middle - 1;
                else if (strcmp(data[middle], word) < 0)
                        low = middle + 1;
                else
                        return middle;
        }
        return -1;
}


int main(int argc, char *argv[]) 
{
        
	FILE *fp = fopen("scrabble.txt", "r");
	char buf[LEN];

        char *tok;
        //char target = (char) *argv[2];

	int i = 0;
	struct data_t *data = malloc(sizeof(struct data_t));
	data->nval = INIT;
	data->max = INIT;
	data->data = NULL;
        char** words;
	while (fgets(buf, LEN, fp)) {
		if (words == NULL)
			words = malloc(sizeof(char*));
		else if (data->nval >= data->max) {
			words = realloc(words, GROW * data->max * sizeof(char *));
			data->max = GROW * data->max;
		}
                tok = strtok(buf, "\n");
		words[i] = sscanf(*tok, "%s");
		i++;
                data->nval++;
	}
        data->data = words;

        /* overcounted */
        data->nval--;
	fclose(fp);

        char buff[1024];
        char buff2[1024];
        char *word = malloc(sizeof(1024));
        int choice;
        while(1) {
                printf("1) find if a word is in the scrabble dictionary\n2) determine the best play for tiles\n");
                printf("3) quit\n");
                fgets(buff, 1024, stdin);
                sscanf(buff, "%d", &choice);
                if (choice == 3)
                        exit(EXIT_SUCCESS);
                else if (choice == 2)
                        printf("not implimented :(\n");
                else if (choice == 1) {
                        printf("word to search for: ");
                        fgets(buff2, 1024, stdin);
                        sscanf(buff2, "%s", word);
                        int ans = search(data->data, data->nval, word);        
                        if (ans == -1)
                                printf("%s is not a valid scrabble word\n", word);
                        else 
                                printf("%s is a valid word\n", word);
                }
        }



        /* no frees! this needs to be fixed */
	return 0;
}

