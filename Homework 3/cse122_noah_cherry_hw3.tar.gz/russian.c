/**
 * @file perma.c
 * @brief fills an array A from A[0] to A[n-1] with a random number not already in A
 * @details 
 *
 * @author Noah
 * @date Spring 2016
 * @bug None or list bugs
 * @todo Optional
 */

#include "randint.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> /* getopt and optarg */

#define LEN 100

/**
 * @param a, the first int in a multiplication problem
 * @param b, the second int in a multiplication problem
 * @return sum, this is the answer to a * b
 */
int russian(int a, int b)
{
        int sum = 0;
        for(; b >= 1; b /= 2, a += a) {
                if((b % 2) == 1)
                        sum += a;
        }
        return sum;
}

void main(int argc, char **argv)
{
	char buf[LEN];
        char *tok;

        fgets(buf, LEN, stdin)

	FILE *in = fopen(buf, "r");

        int a;
        int b;

	while (fgets(buf, LEN, in)) {
		tok = strtok(buf, " ");
                a = atoi(tok);
                tok = strtok(NULL, "\n");
                b = atoi(tok);

                printf("%d * %d = %d\n", a, b, russian(a, b));
                
        }
        fclose(in);

}