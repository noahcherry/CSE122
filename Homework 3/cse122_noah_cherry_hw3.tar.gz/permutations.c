/**
 * @file perma.c
 * @brief fills an array A from A[0] to A[n-1] with a random number not already in A
 * @details 
 *
 * @author Noah
 * @date Spring 2016
 * @bug None or list bugs
 * @todo Optional
 */

#include "randint.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h> /* getopt and optarg */


/**
 * returns a uniform random integer between 0 <= rand num <= range
 * @param range, defines the range of the random number [1,range]  
 * @return the generated random number
 */
int nrandint(int range) 
{
	return rand() % (range + 1);
}

/**
 * call this to seed the random number generator rand()
 * uses a simple seed -- the number of seconds since the epoch 
 * call once before using nrandint and similiar functions that call rand()
 */
void seed(void) 
{
  	srand((unsigned int)time(NULL));
}

/**
 * @param A[], an array to be filled
 * @param range, defines the range of the random number and index of the array 
 */
void lucky(int A[], int range)
{
        int i = 0;
        int c;
        for(i = 0; i < range; i++) {
                A[i] = nrandint(range);
                while((c = check(A, i, A[i])) == 1)
                        A[i] = nrandint(range);
        }
}

int check(int A[], int range, int x)
{
        int i;
        for(i = 0; i < range; i++){
                if(x == A[i]){
                        return 1; 
                }
        }
        return 0;
}

void used(int A[], int used[], int range)
{
        int i = 0;
        int rand;
        for(i = 0; i < range; i++) {
                rand = nrandint(range);
                if(used[rand] != 1) {
                        A[i] = rand;
                        used[rand] = 1;
                }
        }
}

void swap(int *x, int *y) {
        if(x != y) {
                *x = *x ^ *y;
                *y = *x ^ *y;
                *x = *x ^ *y;
        }
}

/**
 * @param A[], an array to be filled
 * @param range, defines the range of the random number and index of the array 
 */
void knuth(int A[], int range)
{
        int i = 0;
        int c;
        for(i = 0; i < range; i++) {
                A[i] = i + 1;
        }
        for(i = 0; i < range; i++) {
                swap(&A[i], &A[nrandint(range - 1)]);
        }
}

void main(int argc, char **argv)
{
        seed();
        int i;
        int j;
        clock_t start, end;
        double avg = 0;
        double total;
        int* A;
        int* U;
        A = (int*) malloc(sizeof(int));
        U = (int*) malloc(sizeof(int));

        //lucky trials
        //n = 250, 500, 1000, 2000
        printf("begin lucky runs");
        for(i = 250; i <= 2000; i *= 2) {
                printf("\n\nrun\tn\ttime\n");
                A = (int*) realloc(A, i * sizeof(int));
                for(j = 0; j < 10; j++) {
                        start = clock();
                        lucky(A, i);
                        end = clock();
                        total = (double)(end - start) / CLOCKS_PER_SEC;
                        avg += total;
                        printf("%d\t%d\t%.4f\n", j + 1, i, total);
                }
                printf("\navg for n = %d for lucky is %.4f seconds", i, avg / 10);
                avg = 0;
        }
        printf("\n");


        //used trials
        //n = 2500, 5000, 10000, 20000, 40000, 80000
        printf("\nbegin used runs");
        for(i = 2500; i <= 80000; i *= 2) {
                printf("\n\nrun\tn\ttime\n");
                A = (int*) realloc(A, i * sizeof(int));
                U = (int*) realloc(U, i * sizeof(int));
                for(j = 0; j < 10; j++) {
                        start = clock();
                        used(A, U, i);
                        end = clock();
                        total = (double)(end - start) / CLOCKS_PER_SEC;
                        avg += total;
                        printf("%d\t%d\t%.4f\n", j + 1, i, total);
                }
                printf("\navg for n = %d for used is %.4f seconds", i, avg / 10);
                avg = 0;
        }
        printf("\n");


        //knuth trials
        //n = 10000, 20000, 40000, 80000, 160000, 320000, 640000
        printf("\nbegin knuth runs");
        for(i = 10000; i <= 640000; i *= 2) {
                printf("\n\nrun\tn\ttime\n");
                A = (int*) realloc(A, i * sizeof(int));
                for(j = 0; j < 10; j++) {
                        start = clock();
                        knuth(A, i);
                        end = clock();
                        total = (double)(end - start) / CLOCKS_PER_SEC;
                        avg += total;
                        printf("%d\t%d\t%.4f\n", j + 1, i, total);
                }
                printf("\navg for n = %d for knuth is %.4f seconds", i, avg / 10);
                avg = 0;
        }
        printf("\n");

}