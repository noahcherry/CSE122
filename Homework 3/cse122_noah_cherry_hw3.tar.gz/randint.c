#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "randint.h"

/**
 * returns a uniform random integer between 0 <= rand num <= range
 * @param range, defines the range of the random number [1,range]  
 * @return the generated random number
 */
int nrandint(int range) 
{
	return rand() % (range + 1);
}

/**
 * call this to seed the random number generator rand()
 * uses a simple seed -- the number of seconds since the epoch 
 * call once before using nrandint and similiar functions that call rand()
 */
void seed(void) 
{
  	srand((unsigned int)time(NULL));
}

void fill(int A[], int range)
{
        int i = 0;
        int c;
        for(i = 0; i < range; i++) {
                A[i] = nrandint(range);
                while((c = check(A, i, A[i])) == 1)
                        A[i] = nrandint(range);
        }
}

int check(int A[], int range, int x)
{
        int i;
        for(i = 0; i < range; i++){
                if(x == A[i]){
                        return 1; 
                }
        }
        return 0;
}

void main()
{
        seed();
        int A[5] = {0};
        fill(A, 5);
        printf("%d, %d, %d, %d, %d\n", A[0], A[1], A[2], A[3], A[4]);

}