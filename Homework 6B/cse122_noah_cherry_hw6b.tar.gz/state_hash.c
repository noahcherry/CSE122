#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define LEN 4096

struct postal_t {
        char *abrv; /*two digit abbreviation, capitalized */
        char *name; /*name in start case */
};


/*  convert string to lowercase */
void tolowercase(char *tok)
{
        char *s = tok;
        while(isalpha(*s)) {
                *s = tolower(*s);
                s++;
        }  
}

/* trim off whitespace and postal code from the right */
void rstrip(char *tok)
{
        char *s = tok + strlen(tok) - 2;
        s--;
        *s = '\0';
        while(isspace(*s)) {
                *s = '\0';
                s--;
        }  
}

/*hash function returns hash value*/
unsigned djb_hash(void* key)
{
        unsigned char* p = key;
        unsigned int h;        

        while(*p) {
                h = 33 * *p;
                p++;
        }

        return h;
}

int quad_probe(struct postal_t *hash, int k, int table_size)
{
        int i;
        int new;
        for(i = 0; i < table_size; i++) {
                new = (k + i * i) % table_size;
                if((hash + i)->name == NULL) {
                        return new;
                }
        }
        return 0;
}

int main(int argc, char *argv[])
{
        /*the line being read*/
        char buf[LEN];
        char* p_code = "AA";
        //char* s_code = "SS";
        char pc[3] = "SS";
        int table_size = 200;
        int k = 0;
        /*the table*/
        struct postal_t *postal = malloc(table_size * sizeof(struct postal_t));

	FILE *fp = fopen("postal", "r");
	assert(fp);

        pc[2] = '\0';

	while(fgets(buf, LEN, fp)) {
	        //printf("%s\n", buf);
                pc[0] = buf[32];
                pc[1] = buf[33];

		//memcpy(&p_code, &pc, strlen(p_code));

                printf("%s\n", pc);

                k = djb_hash(&pc) % table_size;

		rstrip(buf);

                (postal + k)->abrv = malloc(sizeof(char) * 4);
		sprintf(((postal + k)->abrv), "%s", pc);

                if(((postal + k)->name) == NULL) {
                        ((postal + k)->name) = buf;
                }

                else {
                        //printf("%d\n", k);
                        k = quad_probe(postal, k, table_size);
                        ((postal + k)->name) = buf;
                        //printf("%d\n", k);
                }
                //printf("%s\n", buf);
                //printf("%s\n", ((postal + k)->abrv));
        }
        printf("successs\n");
        while(1) {
                printf("enter a two-digit state abbreviation (q to quit): ");
                fgets(buf, 1024, stdin);
                if (*buf == 'q')
                        exit(EXIT_SUCCESS);
                k = djb_hash(buf) % table_size;
                if((postal + k)->name != NULL)
                        printf("%s\n", (postal + k)->name);
                else
                        printf("State not found\n");
        }

        free(postal);
        fclose(fp);
        return 0;
}

