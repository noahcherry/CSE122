#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* i know it says cube dont worry about it just eat the spaghatti code*/
double cube_bin(double n, double epsilon)
{
        int num_guess = 0;
        double guess = 1.0;

        while (fabs(guess * guess * guess - n) >= epsilon) {

                guess = ((2 * guess) / 3) + (n /(3 * guess * guess));
                num_guess++;
        }
        
        printf("%d|", num_guess);

        return guess;

}


int main(void)
{
        double sq_rt = 0.0;
        double i;
        
        for(i = 0; i < 100; i++)
                printf("%0.0f|%0.10f\n", i + 1, cube_bin(i + 1, 0.00000001));

        return 0;
}

