#include "stdio.h"

int main(void) {
        int i;
        for(i = 0; i < 100; i++) {
                if(!(i % 5))
                        printf("Fizz");
                if(!(i % 3))
                        printf("Buzz");
                if ((i % 5) && (i % 3))
                        printf("%d", i);
                printf("\n");
        }
}