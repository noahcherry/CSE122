#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX(x, y) ((x) >= (y) ? (x) : (y))

/* binary search cube root */
double cube_bin(double n, double epsilon)
{
        int num_guess = 0;
        double cube_rt = 0.0;
        double low = 0.0;
        double high = MAX(1.0, n);

        while (fabs(cube_rt * cube_rt * cube_rt - n) >= epsilon) {

                cube_rt = (low + high)/2.0;

                if (cube_rt * cube_rt * cube_rt > n) 
                        high = cube_rt;
                else
                        low = cube_rt;
                num_guess++;
        }
        
        printf("%d|", num_guess);

        return cube_rt;

}


int main(void)
{  
        double i;
        double sq_rt = 0.0;

        for(i = 0; i < 100; i++)
                printf("%f|%f\n", i + 1, cube_bin(i + 1, 0.000001));

        return 0;
}

