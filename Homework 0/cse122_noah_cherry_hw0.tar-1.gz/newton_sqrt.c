#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* i know it says cube dont worry about it just eat the spaghatti code*/
double cube_bin(double n, double epsilon)
{
        int num_guess = 0;
        double guess = 1.0;

        while (fabs(guess * guess - n) >= epsilon) {

                guess = (guess + n / guess) / 2;        //i have no idea why this works I thought it should be "guess - (n / guess) / 2" but that didnt work at all so i played with some signs and this works perfectly
                num_guess++;
        }
        
        printf("%d|", num_guess);

        return guess;

}


int main(void)
{
        double sq_rt = 0.0;
        double i;
        
        for(i = 0; i < 100; i++)
                printf("%0.0f|%0.10f\n", i + 1, cube_bin(i + 1, 0.000000000001));

        return 0;
}

