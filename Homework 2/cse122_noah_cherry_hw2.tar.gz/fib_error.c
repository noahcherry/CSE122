/**
 * @file fib.c
 * @brief compares calculated fibbonacci numbers to those found the hard way
 * @details also finds highest n term possible for your computer
 *
 * @author Noah
 * @date Spring 2016
 * @bug None or list bugs
 * @todo Optional
 */

#include <limits.h> /*ULONG_MAX*/
#include <math.h>   /*sqrt, pow, log, compile with -lm*/
#include <stdio.h>
#include <stdlib.h> /* atoi, malloc, realloc, free*/
#include <unistd.h> /* getopt and optarg */

unsigned max_n(void);
double fib(unsigned n);
unsigned long * fib_array(unsigned n);

int main()
{
        int i, lim = 47;
        unsigned long* array = fib_array(lim);        
        /*printf out array*/
        for(i = 0; i <= lim; i++) {
                printf("f[%d] =\t%lu\n", i, array[i]);
        }
        
        printf("\n\n");
        for(i = 0; i < lim; i++) {
                if( array[i] != (unsigned long) fib(i - 1)) {
                        unsigned long diff = array[i] - (unsigned long) fib(i - 1);
                        float re = ((double) diff / (double) array[i]) * 100;
                        printf("error in %d term of formula Fibonacci\n", i);
                        printf("terms differ by %lu\n", diff);
                        printf("percentage error %f%%\n\n", re);
                }
        }

        free(array);
        return 0;
}

/**
* find the lergest term possible for the computer running this program
* @return the maximum n that can be found before overflow happens
*/
unsigned max_n(void) {
        double b = ((1 + sqrt(5)) / 2);
        double n = (log10(ULONG_MAX * sqrt(5)) / log10(b));

        n = floor(n);
        return (unsigned) n;
}

/**
* Finds a specified fibonacci term
* @param n the term to find
* @return the term
*/
double fib(unsigned n) {
        double a =((1 + sqrt(5)) / 2);
        double b =((1 - sqrt(5)) / 2);
        double fib = (1 / sqrt(5)) * (pow(a, n + 1) - pow(b, n + 1));

        return fib;
}

/**
* builds and fills an array with n fib numbers
* @param n the highest fib term desired
* @return the array
*/
unsigned long * fib_array(unsigned n) {
        unsigned long* array, i;        //array and number to add to array
        int size = 0;                       //number of elements in the array
        array = (unsigned long*) malloc(sizeof(unsigned long));
        /*set F0 to 0 and F1 to 1*/
        array[size] = 0;
        if(n == 1)
                return array; 

        array = (unsigned long*) realloc(array, (size + 1) * sizeof(unsigned long));
        array[size + 1] = 1;
        if(n == 1)
                return array;
        /*fill the array with n fib terms*/
        /* reallocs as needed*/
        for(size = 2; size <= n; size++) {
                array = (unsigned long*) realloc(array, (size + 1) * sizeof(unsigned long));
                //i = fib(size - 1);
                i = array[size - 1] + array[size - 2];
                array[size] = i;                
        }
        return array;
}





