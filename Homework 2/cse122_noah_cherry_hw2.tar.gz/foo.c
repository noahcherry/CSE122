#include <stdio.h>
#include <stdlib.h> /* atoi */
#include <unistd.h> /* getopt and optarg */
#include <time.h>

unsigned long foo1(unsigned long n){
        unsigned long sum = 0;
        unsigned long i;
        for (i = 0; i < n; i++)
                sum++;
}

unsigned long foo2(unsigned long n){
        unsigned long sum = 0;
        unsigned long i;
        unsigned long j;
        for (i = 0; i < n; i++) {
                for (j = 0; j < n; j++)
                        sum++;
        }
}
unsigned long foo3(unsigned long n){
        unsigned long sum = 0;
        unsigned long i;
        unsigned long j;
        for (i = 0; i < n; i++) {
                for (j = 0; j < n * n; j++)
                        sum++;
        }
}
unsigned long foo4(unsigned long n){
        unsigned long sum = 0;
        unsigned long i;
        unsigned long j;
        for (i = 0; i < n; i++) {
                for(j = 0; j < i; j++)
                        sum++;
        }
}
unsigned long foo5(unsigned long n){
        unsigned long sum = 0;
        unsigned long i;
        unsigned long j;
        unsigned long k;
        for (i = 0; i < n; i++) {
                for(j = 0; j < i * i; j++) {
                        for(k = 0; k < j; k++)
                                sum++;
                }
        }
}
unsigned long foo6(unsigned long n){
        unsigned long sum = 0;
        unsigned long i;
        unsigned long j;
        unsigned long k;
        for (i = 1; i < n; i++) {
                for(j = 1; j < i * i; j++) {
                        if (j % i == 0) {
                                for(k = 0; k < j; k++)
                                sum++;
                        }
                }
        }
}

int main(int argc, char **argv) {
        int i;
        unsigned long sum, n = 1;
        clock_t start, end;
        double total;        
        for(n = 1; n <= 100; n = n * 10) {
                start = clock();

                sum = foo6(n);

                end = clock();
                total = (double)(end - start) / CLOCKS_PER_SEC;
                printf("%lu|%lu|%f\n", n, sum, total);
        }
        return 0;
}