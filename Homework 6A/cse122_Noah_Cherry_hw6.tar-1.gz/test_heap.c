#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "heapsort.h"

#define LEN 4096

/*  convert string to lowercase */
void tolowercase(char *tok)
{
        char *s = tok;
        while(isalpha(*s)) {
                *s = tolower(*s);
                s++;
        }  
}

/* trim off whitespace see the manpage for isspace as to what is considered whitespace */
void rstrip(char *tok)
{
        char *s = tok + strlen(tok) - 1;
        while(isspace(*s)) {
                *s = '\0';
                s--;
        } 
}

static int cmpstring(const void *p1, const void *p2)
{
        return strcmp(* (char * const *) p1, * (char * const *) p2);
}

int main(int argc, char *argv[])
{
        char buf[LEN];
	char *t = NULL;

	char **list = NULL;
	int word = 1;
	int i;
	FILE *fp;

	fp = fopen(argv[1], "r");
	assert(fp);

        /* this leaks  you need to fix*/
	while(fgets(buf, LEN, fp)) {
		/* remove new line */
		rstrip(buf); 
		tolowercase(buf);
		t = malloc((strlen(buf) + 1) * sizeof(char));
                assert(t);
		strncpy(t, buf, strlen(buf) + 1);
		/* printf("%s\n", t);  */
		list = realloc(list, word * sizeof(char *)); 
		list[word - 1] = t; 
		word++;
	}
        /* overcounted */
        word--;
    
        /* print the list */
	for(i = 0; i < word; i++) 
		printf("%s\n", list[i]);

        printf("\n");

	/* todo sort list with heapsort */
        heapsort(&(*list), word, sizeof(char *), cmpstring);
        /* user needs to provide comparison function */
	
        /* print the sorted list */
        for(i = 0; i < word; i++) 
		printf("%s\n", list[i]);
 
       return 0; 
}
