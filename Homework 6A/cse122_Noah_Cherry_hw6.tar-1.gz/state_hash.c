#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define LEN 4096

struct postal_t {
        char *abrv; /*two digit abbreviation, capitalized */
        char *name; /*name in start case */
};


/*  convert string to lowercase */
void tolowercase(char *tok)
{
        char *s = tok;
        while(isalpha(*s)) {
                *s = tolower(*s);
                s++;
        }  
}

/* trim off whitespace from the right */
void rstrip(char *tok)
{
        char *s = tok + strlen(tok) - 1;
        while(isspace(*s)) {
                *s = '\0';
                s--;
        }  
}


unsigned djb_hash(void* key)
{
        unsigned char* p = key;
        unsigned h = 0;
        
        while(*p) {
                h = 33 * h + *p;
                p++;
        }

        return h;
}

int quad_probe(struct postal_t *hash, int k, int tlbsz)
{
        int i;
        int new;
        for(i = 0; i < tlbsz; i++) {
                new = (k + i * i) % tlbsz;
                if((hash + i)->name == NULL) {
                        return new;
                }
        }
        return 0;
}

int main(int argc, char *argv[])
{
        char buf[LEN];
	char *t = NULL;
        int tlbsz = 200;
        int i = 0;
        int j = 0;
        int h = 0;
        struct postal_t *postal = malloc(tlbsz * sizeof(struct postal_t));
        struct postal_t *temp = postal;

	FILE *fp = fopen("postal", "r");
	assert(fp);

	while(fgets(buf, LEN, fp)) {
	        //printf("%s\n", buf);
		rstrip(buf); 
		t = malloc((strlen(buf) + 1) * sizeof(char));
                assert(t);
		strncpy(t, buf, strlen(buf) + 1);

                int k = djb_hash(buf);
                //if(((postal + (k % tlbsz))->name) == NULL) {
                        printf("%s\n", buf);
                        printf("%d\n", (tlbsz));
                        ((postal + (k % tlbsz))->name) = t;
                        printf("%s\n", buf);
                        //j++;
                //}
               /* else {
                        j++;
                        if(quad_probe(postal, k, tlbsz) != 0)
                                ((postal + quad_probe(postal, k, tlbsz))->name) = t;
                        else
                                break;
                }*/                
                //printf("%s\n", (postal + (k % tlbsz))->name);
                //i++;                
        }
        printf("%s\n", (postal)->name);
        fclose(fp);
        return 0;
}

