#include "heapsort.h"
#include <sys/types.h>
#include <string.h>

int heapsort(void *base, size_t nel, size_t width, int (*compar)(const void *, const void *))
{
        /* todo generic heapsort */
        /* note you have to do pointer arthimetic with void pointers */
        /* can't use array notation, base[i] as that makes no sense as base is a void pointer  */
        /* correct way to get the i-th element is (base + i * width) */
        int i;
        for (i = nel / 2; i >= 0; i--) {
                while (i * 2 + 1 < nel) {
                        int kiddo = 2 * i + 1;  //default left child
                        char* ele1 = (char *)base + i * width;
                        char* ele2 = (char *)base + kiddo * width;
                        if (kiddo + 1 < nel) {                    /*find the smallest child of i*/
                                if (compar(ele2, ele1) > 0)    /*compare l and r child to find smallest*/
                                        kiddo += 1;
                        }
                        
                        ele2 = (char *)base + kiddo * width;

                        if(compar(ele1, ele2) > 0) { 
                                char* buff[1024];
                                memcpy(buff, ele1, width);               /*swap parent w/ child if its larger*/
                                memcpy(ele1, ele2, width);
                                memcpy(ele2, buff, width);
                                i = kiddo;                                      /*new node to examine in next loop iteration*/
                        }
                        else
                                break;
                }
        }

        return 0;
}