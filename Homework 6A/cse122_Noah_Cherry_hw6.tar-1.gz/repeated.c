#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* strchrrep(char* s, size_t len)
{
        size_t width = sizeof(char *);
        int count[128] = {0};
        int i;
        int j;
        char c;
        
        for(i = 0; i < len; i++) {
                int j = *(s + i);
                count[j]++;
                if(count[j] > 1) {
                        //printf("%c\n", (char) *(s + i + 1));
                        return (char*)(s + i + 1);
                }
        }
        return NULL;

}

int main(int argc, char **argv)
{  	
	if (argc != 2) {
		printf("error in input\n");
		printf("usage: ./repeated [STRING]\n");
		printf("where [STRING] is the string to find the first repeated character in\n");
		exit(EXIT_FAILURE);
	}

        /* call strchrrep(argv[1]) */;
        char* c = strchrrep(argv[1], strlen(argv[1]));

        printf("first repeated character is:\t %c\n", *c);
	/* print the first repeated char in argv[1] */
	
	return 0;
}